import java.io.IOException;
import java.io.PrintWriter;

public class Main {

    public static void main(String[] args) throws IOException {
        MyGame myGame = new MyGame();
        myGame.start();

       // myGame.setVisible(true);

        PrintWriter najlepszyWynik = new PrintWriter("Najlepszy wynik");
        najlepszyWynik.println("Najlepszy wynik gracza to "+ myGame.gamePanel.najlepszyWynik );
        najlepszyWynik.close();


    }
}
