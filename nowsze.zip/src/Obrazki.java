import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Obrazki {

    BufferedImage chmura;
    BufferedImage ptakZiel;
    List<Obrazek> obrazki1=new ArrayList<Obrazek>();
    Obrazek chmura1=new Obrazek();
    Obrazek chmura2=new Obrazek();
    Obrazek chmura3= new Obrazek();
    Obrazek ptak = new Obrazek();



    public Obrazki() throws IOException {
        chmura=ImageIO.read(new File("Obrazki/dobra chmura.png"));
        ptakZiel=ImageIO.read(new File("Obrazki/bird power.png"));
        obrazki1.add(chmura1);
        chmura1.posX=100;
        chmura1.posY=50;
        obrazki1.add(chmura2);
        chmura2.posX=600;
        chmura2.posY=40;
        obrazki1.add(chmura3);
        chmura3.posX=1100;
        chmura3.posY=30;
       // obrazki1.add(ptak);
        //ptak.posX=1000;
       // ptak.posY=30;
    }


    public void update (){

        for (Obrazek obrazek: obrazki1){
            obrazek.posX=obrazek.posX-0.1;

        }
        Obrazek chmureczka=obrazki1.get(0);
        if (chmureczka.posX+chmura.getWidth()<0){
            chmureczka.posX=1500;
            obrazki1.remove(chmureczka);
            obrazki1.add(chmureczka);
        }
    }

        public void draw (Graphics g){
            for (Obrazek obrazek: obrazki1) {
                g.drawImage(chmura, (int)obrazek.posX, (int)obrazek.posY, null);

            }
           // g.drawImage(ptakZiel,(int)obrazek.posX,(int)obrazek.posY,null);

    }


}
class Obrazek{

    double posX;
    double posY;

}
