import javax.swing.*;
import java.awt.*;
import java.io.IOException;


public class GamePanel extends JPanel{

// gamescreen
    static double gravity=0.9;
    static double powierzchnia=600;
    Minionki minion;
    Obrazki chmurka= new Obrazki();
    Przeszkody kaktus= new Przeszkody(minion);
    Omijanie omijanie =new Omijanie(minion,this);
    int wynik;

    static final int gameFirstState=0;
   static final int gamePlay=1;
   static final int gameOver=2;
   static int gameState=gameFirstState;

 /*  public void start(){

    switch (GamePanel.gameState){
        case GamePanel.gamePlay:
          update();
          omijanie.proba();
            if (!minion.isAlive) {
                gameState = gameOver;
            } break;
    }
}
*/
public void czyDziala(){
    switch (GamePanel.gameState) {
        case GamePanel.gamePlay:

            break;
    }
}


    public GamePanel() throws IOException {
    minion=new Minionki();
}

public void start1(){
}

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
       // g.setColor(Color.GREEN);
       // g.fillRect(x,y,100,100);
       // g.fillRect(0,0,getWidth(),getHeight());
      //  g.drawRect((int)getX(),(int)getY(),100,100);
        g.setColor(Color.BLACK);
        g.drawLine(0,(int)powierzchnia,getWidth(),(int)powierzchnia);
        switch (gameState){
            case gameFirstState:
                minion.draw(g);
                break;
            case gamePlay:
                chmurka.draw(g);
                minion.draw(g);
                kaktus.draw(g);
                omijanie.draw(g);
                g.drawString("Nalepszy wynik : "+String.valueOf(wynik),400,200);
                break;

        }

        //  g.drawImage(minionki,0,0,this);

}


    public void update() {

        switch (GamePanel.gameState){
            case GamePanel.gamePlay:
                //update();
                minion.update();
                chmurka.update();
                kaktus.updateabstra();
                omijanie.update111();
              //  omijanie.proba();
               // if (!minion.isAlive) {
                //    gameState = gameOver;
              //  }
                break;
        }
        if ( kaktus.omijane().intersects(minion.omijane())){

                System.out.println("Kolizja");
        }

}
public void gameUpdate(){
    if ( gameState==gamePlay){
        minion.update();
        chmurka.update();
        kaktus.updateabstra();
        omijanie.update111();
        if (omijanie.kolizja()){
            gameState=gameOver;
        }
    }
}


public void setWynik(int wynik){
    this.wynik+=wynik;
}


    public  double getGravity() {
        return gravity;
    }

    public  void setGravity(double gravity) {
        this.gravity = gravity;
    }



    public  void setPowierzchnia(double powierzchnia) {
        this.powierzchnia = powierzchnia;
    }
    public double getPowierzchnia() {
        return powierzchnia;
    }

}

