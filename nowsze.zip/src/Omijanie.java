import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Omijanie {

    List<OmijanePrzedmioty> omijanie ;
    Random random = new Random();
    BufferedImage kaktus1,kaktus2,skala;
    Minionki minionki;
    Przeszkody kaktus12 = new Przeszkody(minionki);
    GamePanel gamePanel;


    public Omijanie(Minionki minionki,GamePanel gamePanel) throws IOException {
        this.minionki =minionki;
        this.gamePanel=gamePanel;
        omijanie = new ArrayList<>();
        kaktus1 = ImageIO.read(new File("Obrazki/cactus Power.png"));
        kaktus2=ImageIO.read(new File("Obrazki/cactus Power.png"));
        skala = ImageIO.read(new File("Obrazki/rock power.png"));
       // omijanie.add(losowePrzeszkody());
        omijanie.add(kaktus12);


        omijanie.add(losowePrzeszkody());

    }


    public void update111() {
        for (OmijanePrzedmioty o : omijanie) {
            o.updateabstra();
           // if (o.koniecGry()&& !o.toWynik()){
                //gamePanel.setWynik(20);
                //o.settowynik(true);
           // }
//to powinno byc w ifie ktory wwywala obecnie blad

        }
        OmijanePrzedmioty first = omijanie.get(0);
        if (first.isOutofScreen()) {

            omijanie.remove(first);
            omijanie.add(losowePrzeszkody());
        }
    }
    // tu mi sie wywala blad !!!!!!
public boolean kolizja() {
    for (OmijanePrzedmioty o : omijanie) {
        if (minionki.omijane().intersects(o.omijane())) {
            // minionki.setAlive(false);
            return true;
        }
    }
        return  false;
    }


    public void draw(Graphics g) {

        for (OmijanePrzedmioty p : omijanie) {
            p.draw(g);


        }
    }

    public Przeszkody losowePrzeszkody() {

        Przeszkody p = new Przeszkody(minionki);
        p.setOdleglosc(1500);

        if (random.nextBoolean()) {
           p.setPrzeszkoda(kaktus1);
        }
        else  {
            p.setPrzeszkoda(skala);
            p.setWys(550);

        }

        return p;



}



}
