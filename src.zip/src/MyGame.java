import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

public class MyGame extends JFrame {

    GamePanel gamePanel;


    public MyGame() throws IOException {
        super("Minions game");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        this.setSize(1500,768);
        this.setVisible(true);
       // addKeyListener();

        (new Timer(0, (ActionEvent a) -> {
            this.gamePanel.update();
            this.gamePanel.repaint();
        })).start();

    }
    public void start(){

        gamePanel.start1();
    }

    private void initComponents() throws IOException {

        this.addKeyListener(new KeyListener() {


                                @Override
                                public void keyTyped(KeyEvent e) {

                                }

                                @Override
                                public void keyPressed(KeyEvent e) {
                                gamePanel.minion.skocz();

                                }

                                @Override
                                public void keyReleased(KeyEvent keyEvent) {

                                }

                            });
            gamePanel = new GamePanel();
        this.add(gamePanel, BorderLayout.CENTER);
    }



}
