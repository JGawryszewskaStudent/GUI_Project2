import java.awt.*;

public abstract class OmijanePrzedmioty {
    public abstract Rectangle omijane();
    public abstract void draw(Graphics g);
    public abstract void updateabstra();
    public abstract boolean isOutofScreen();

}
