import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Omijanie {

    List<OmijanePrzedmioty> omijanie ;
    Przeszkody kaktus12 = new Przeszkody();
    Random random = new Random();
    BufferedImage kaktus1,kaktus2,skala;


    public Omijanie() throws IOException {
        omijanie = new ArrayList<>();
        kaktus1 = ImageIO.read(new File("Obrazki/cactus Power.png"));
        kaktus2=ImageIO.read(new File("Obrazki/cactus Power.png"));
        skala = ImageIO.read(new File("Obrazki/rock power.png"));
       // omijanie.add(losowePrzeszkody());
        omijanie.add(kaktus12);


        omijanie.add(losowePrzeszkody());

    }


    public void update()  {
        for (OmijanePrzedmioty o : omijanie) {
            o.updateabstra();

           // o.omijane().width
        }
        OmijanePrzedmioty first=omijanie.get(0);
        if ( first.isOutofScreen()){

            omijanie.remove(first);
            omijanie.add(losowePrzeszkody());
        }

    }

    public void draw(Graphics g) {

        for (OmijanePrzedmioty p : omijanie) {
            p.draw(g);


        }
    }

    public Przeszkody losowePrzeszkody() {

        Przeszkody p = new Przeszkody();
        p.setOdleglosc(1500);

        if (random.nextBoolean()) {
           p.setPrzeszkoda(kaktus1);
        }
        else  {
            p.setPrzeszkoda(skala);
            p.setWys(550);

        }

        return p;



}



}
