import javax.swing.*;
import java.awt.*;
import java.io.IOException;


public class GamePanel extends JPanel{


    static double gravity=0.9;
    static double powierzchnia=600;
    Minionki minion;
    Obrazki chmurka= new Obrazki();
    Przeszkody kaktus= new Przeszkody();
    Omijanie omijanie=new Omijanie();



    public GamePanel() throws IOException {

minion=new Minionki();



}
public void start1(){


}

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
       // g.setColor(Color.GREEN);
       // g.fillRect(x,y,100,100);
       // g.fillRect(0,0,getWidth(),getHeight());
      //  g.drawRect((int)getX(),(int)getY(),100,100);
        g.setColor(Color.BLACK);
        g.drawLine(0,(int)powierzchnia,getWidth(),(int)powierzchnia);
        minion.draw(g);
        chmurka.draw(g);
       kaktus.draw(g);
        omijanie.draw(g);


   //  g.drawImage(minionki,0,0,this);

    }

   /* public void addMoveX(int move){
        this.x += move;
    }

    public void addMoveY(int move){
        this.y += move;
    }*/

    public void update() {


            minion.update();
            chmurka.update();
            kaktus.updateabstra();

               omijanie.update();
            if ( kaktus.getBound().intersects(minion.getBound())){
                System.out.println("Kolizja");

            }


    }



    public  double getGravity() {
        return gravity;
    }

    public  void setGravity(double gravity) {
        this.gravity = gravity;
    }



    public  void setPowierzchnia(double powierzchnia) {
        this.powierzchnia = powierzchnia;
    }
    public double getPowierzchnia() {
        return powierzchnia;
    }

}

