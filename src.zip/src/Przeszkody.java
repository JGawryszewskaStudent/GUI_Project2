import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Przeszkody extends OmijanePrzedmioty{

    BufferedImage kaktus;
    int odleglosc;
    int wys;
   // BufferedImage skala;
    Rectangle rect = new Rectangle();


    public Przeszkody() {
        odleglosc = 600;
        wys = 500;

        try {
            kaktus = ImageIO.read(new File("Obrazki/cactus Power.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        // skala = ImageIO.read(new File("Obrazki/rock power.png"));
//rect.intersects(rect);

    }
/*
    public void kaktusik() {

        szer -= 5;
        rect.x = szer;
        rect.y = wys;
        rect.width = kaktus.getWidth();
        rect.height = kaktus.getHeight();
    }*/

    public Rectangle getBound() {
        return rect;
    }




    @Override
    public Rectangle omijane() {
        return rect;
    }

    @Override
    public void draw(Graphics g) {
        g.drawImage(kaktus, odleglosc, wys, null);
    }

    @Override
    public void updateabstra() {
        odleglosc -= 1;
        rect.x = odleglosc;
        rect.y = wys;
        rect.width = kaktus.getWidth();
        rect.height = kaktus.getHeight();
    }

    @Override
    public boolean isOutofScreen() {
      return ( odleglosc +kaktus.getWidth()<0);


    }

    public void setOdleglosc(int x) {
        this.odleglosc = x;
    }
    public void setWys(int y) {
        this.wys =y;
    }

    public void setPrzeszkoda(BufferedImage kaktus){
this.kaktus=kaktus;

    }


}
