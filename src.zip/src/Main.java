import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        MyGame myGame = new MyGame();
        myGame.start();
       // myGame.setVisible(true);


    }
}
